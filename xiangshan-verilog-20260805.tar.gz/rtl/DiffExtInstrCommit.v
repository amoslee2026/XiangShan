
`ifndef SYNTHESIS
`ifdef DIFFTEST
`include "DifftestMacros.svh"
`endif // DIFFTEST
`endif // SYNTHESIS
module DiffExtInstrCommit(
  input         clock,
  input         enable,
  input         io_valid,
  input         io_skip,
  input         io_isRVC,
  input         io_rfwen,
  input         io_fpwen,
  input         io_vecwen,
  input         io_v0wen,
  input  [ 8:0] io_wpdest,
  input  [ 7:0] io_wdest,
  input  [ 8:0] io_otherwpdest_0,
  input  [ 8:0] io_otherwpdest_1,
  input  [ 8:0] io_otherwpdest_2,
  input  [ 8:0] io_otherwpdest_3,
  input  [ 8:0] io_otherwpdest_4,
  input  [ 8:0] io_otherwpdest_5,
  input  [ 8:0] io_otherwpdest_6,
  input  [ 8:0] io_otherwpdest_7,
  input  [ 8:0] io_otherwpdest_8,
  input  [ 8:0] io_otherwpdest_9,
  input  [ 8:0] io_otherwpdest_10,
  input  [ 8:0] io_otherwpdest_11,
  input  [ 8:0] io_otherwpdest_12,
  input  [ 8:0] io_otherwpdest_13,
  input  [ 8:0] io_otherwpdest_14,
  input  [ 8:0] io_otherwpdest_15,
  input  [63:0] io_pc,
  input  [31:0] io_instr,
  input  [ 9:0] io_robIdx,
  input  [ 6:0] io_lqIdx,
  input  [ 6:0] io_sqIdx,
  input         io_isLoad,
  input         io_isStore,
  input  [ 7:0] io_nFused,
  input  [ 7:0] io_special,
  input  [ 7:0] io_coreid,
  input  [ 7:0] io_index
);
  wire _dummy_unused = 1'b1;
`ifndef SYNTHESIS
`ifdef DIFFTEST
`ifndef CONFIG_DIFFTEST_FPGA

import "DPI-C" function void v_difftest_InstrCommit (
  input       bit io_skip,
  input       bit io_isRVC,
  input       bit io_rfwen,
  input       bit io_fpwen,
  input       bit io_vecwen,
  input       bit io_v0wen,
  input  shortint io_wpdest,
  input      byte io_wdest,
  input  shortint io_otherwpdest_0,
  input  shortint io_otherwpdest_1,
  input  shortint io_otherwpdest_2,
  input  shortint io_otherwpdest_3,
  input  shortint io_otherwpdest_4,
  input  shortint io_otherwpdest_5,
  input  shortint io_otherwpdest_6,
  input  shortint io_otherwpdest_7,
  input  shortint io_otherwpdest_8,
  input  shortint io_otherwpdest_9,
  input  shortint io_otherwpdest_10,
  input  shortint io_otherwpdest_11,
  input  shortint io_otherwpdest_12,
  input  shortint io_otherwpdest_13,
  input  shortint io_otherwpdest_14,
  input  shortint io_otherwpdest_15,
  input   longint io_pc,
  input       int io_instr,
  input  shortint io_robIdx,
  input      byte io_lqIdx,
  input      byte io_sqIdx,
  input       bit io_isLoad,
  input       bit io_isStore,
  input      byte io_nFused,
  input      byte io_special,
  input      byte io_coreid,
  input      byte io_index
);


  always @(posedge clock) begin
    if (enable)
      v_difftest_InstrCommit (io_skip, io_isRVC, io_rfwen, io_fpwen, io_vecwen, io_v0wen, io_wpdest, io_wdest, io_otherwpdest_0, io_otherwpdest_1, io_otherwpdest_2, io_otherwpdest_3, io_otherwpdest_4, io_otherwpdest_5, io_otherwpdest_6, io_otherwpdest_7, io_otherwpdest_8, io_otherwpdest_9, io_otherwpdest_10, io_otherwpdest_11, io_otherwpdest_12, io_otherwpdest_13, io_otherwpdest_14, io_otherwpdest_15, io_pc, io_instr, io_robIdx, io_lqIdx, io_sqIdx, io_isLoad, io_isStore, io_nFused, io_special, io_coreid, io_index);
  end
`endif // CONFIG_DIFFTEST_FPGA
`endif // DIFFTEST
`endif // SYNTHESIS
endmodule

